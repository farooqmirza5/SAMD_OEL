package com.example.samdoelmid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Rooms extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms);

        Button btn1=findViewById(R.id.btn_on);
        Button btn2=findViewById(R.id.btn_off);
        Button btn3=findViewById(R.id.btn_on1);
        Button btn4=findViewById(R.id.btn_off1);
        Button btn11=findViewById(R.id.btn_on11);
        Button btn22=findViewById(R.id.btn_off22);
        Button btn33=findViewById(R.id.btn_on33);
        Button btn44=findViewById(R.id.btn_off44);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Led turned on.",Toast.LENGTH_SHORT).show();

            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Ac turned on.",Toast.LENGTH_SHORT).show();

            }
        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Led turned off.",Toast.LENGTH_SHORT).show();

            }
        });


        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Ac turned off.",Toast.LENGTH_SHORT).show();

            }
        });

        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Led turned on.",Toast.LENGTH_SHORT).show();

            }
        });

        btn33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Fan turned on.",Toast.LENGTH_SHORT).show();

            }
        });


        btn22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Led turned off.",Toast.LENGTH_SHORT).show();

            }
        });


        btn44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Fan turned off.",Toast.LENGTH_SHORT).show();

            }
        });
    }
}